package superclasses;

public class Staff extends Person{
String staffId;
String officeNumber;
	public Staff(String name, String dateOfBirth, String staffId, String officeNumber) {
		super(name, dateOfBirth);
		this.staffId = staffId;
		this.officeNumber = officeNumber;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public String toString() {
		return "Staff [staffId=" + staffId + ", officeNumber=" + officeNumber + ", name=" + name + ", dateOfBirth="
				+ dateOfBirth + "]";
	}

}
