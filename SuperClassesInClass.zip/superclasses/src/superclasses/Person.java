package superclasses;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Person {
String name;
Date dateOfBirth;
	public Person(String name, String dateOfBirth) {
		// TODO Auto-generated method stub
		this.name = name;
		SimpleDateFormat dateFormatter = new SimpleDateFormat("d/M/Y");
		try{
			this.dateOfBirth = dateFormatter.parse(dateOfBirth);
		}catch(ParseException e){
			System.out.println("Unparsable date" + dateOfBirth);
			e.printStackTrace();
		}
	}
}
