package superclasses;

public class Controller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student students = new Student("Harry Beggs", "09/01/1999", "1111", "2222");
		System.out.println(students);
		Staff staffMembers = new Staff("Ged Mullen", "06/09/1989", "1111", "1234");
		System.out.println(staffMembers);
	}

}
